<!DOCTYPE html>
<html>
<head>
	<title>Variáveis</title>
</head>
<body>
	<?php  

		//String
		$nome = "Thiago Traue";

		//int
		$idade = 33;

		//float
		$peso = 90.8;

		//boolean
		$fumante = true;

		//$peso = "teste";
	?>

	<?= var_dump($fumante) ?>

	<h1>Dados do usuário</h1>
	<br/>
	<p>Nome: <?= $nome ?> </p>
	<p>Idade: <?= $idade ?> </p>
	<p>Peso: <?= $peso ?> </p>
	<p>Fumante: <?= $fumante ?> </p>
</body>
</html>





