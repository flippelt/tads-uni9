<!DOCTYPE html>
<html>
<head>
	<title>Constantes</title>
</head>
<body>
	<?php 
		// variáveis constantes:

		define('DB_URL', 'endereco_bd');
		define('DB_USUARIO', 'root');
		define('DB_SENHA', 1234);

		echo DB_URL.'<br/>';
		echo DB_USUARIO .'<br/>';
		echo DB_SENHA. '<br/>';

		echo var_dump(DB_SENHA);

		//define('nome', 'XPTO'); -> Variáveis constantes não podem ser sobrescritas
	?>
</body>
</html>