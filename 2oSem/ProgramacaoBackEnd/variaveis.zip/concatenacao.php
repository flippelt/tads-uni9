<!DOCTYPE html>
<html>
<head>
	<title>Concsatenação</title>
</head>
<body>

	<?php
		$nome = "Thiago";
		$cor = "azul";
		$idade = 66;
		$hobbie = "cozinhar e programar";


		//operador ".":
		echo 'Olá ' .$nome .', vi que sua cor preferida é ' .$cor . ', que você possui ' . $idade . ' anos e que gosta muito de '. $hobbie;

		echo '<br/>';

		//echo com aspas duplas, sem a necessidade do ".""
		echo "Olá $nome, vi que sua cor preferida é $cor, que você possui $idade anos e que gosta muito de $hobbie";

		echo "<br/>Olá " . $nome . ", tudo bem?";

		echo '<br/>Olá . $nome ., tudo bem?'; //assim está errado!
	?>
</body>

</html>